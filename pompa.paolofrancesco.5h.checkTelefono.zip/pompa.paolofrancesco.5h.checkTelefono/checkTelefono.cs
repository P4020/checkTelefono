using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;

public static class Telefono
{

    public static string Check(string[] input)
    {

        foreach (string stringa in input)
        {
            // Verifica se la stringa inizia con +39 ed è lunga 13
            if (Regex.IsMatch(stringa, @"^\+39\d{11}$"))
            {
                return stringa;
            }
            // Verifica se la stringa inizia con 0039 ed è lunga 14
            else if (Regex.IsMatch(stringa, @"^0039\d{11}$"))
            {
                return stringa;
            }
            // Verifica se la stringa inizia con 3 ed è lunga 10
            else if (Regex.IsMatch(stringa, @"^3\d{9}$"))
            {
                return stringa;
            }
        }
    }
}